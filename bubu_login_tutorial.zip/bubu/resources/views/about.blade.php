@extends('app')

@section('title', 'About Us Page')