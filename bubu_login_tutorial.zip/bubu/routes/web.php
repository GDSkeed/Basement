<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('HOME');
})->name('home');
 
Route::prefix('users')->group(function(){
    
    Route::get('users/{user_id}', function ($id) {
        return $id;
    })->name('user_profile');

    Route::get('/{user_id}/books', function ($id) {
        return 'List of books for User with ID of '. $id;
    })->name('user_books');

    Route::get('/{user_id}/cars', function ($id) {
        return 'List of cars for User with ID of '. $id;
    })->name('user_cars'); 

});

Route::get('/hello', 'HelloController@index');
