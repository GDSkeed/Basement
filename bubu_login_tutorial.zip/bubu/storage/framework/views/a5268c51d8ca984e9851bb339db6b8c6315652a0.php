<h1>Hello</h1>

<p>Learning Laravel 6</p>

<?php /**PATH C:\xampp\bubu\resources\views/hello.blade.php ENDPATH**/ ?>