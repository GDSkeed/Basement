<h1><?php echo e($coolString); ?></h1>

<p>Learning Laravel 6</p>

<?php /**PATH C:\xampp\bubu\resources\views/subviews/hello.blade.php ENDPATH**/ ?>