<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

print "hello test 001";
 ?><?php /**PATH C:\xampp\bubu\resources\views/films.blade.php ENDPATH**/ ?>