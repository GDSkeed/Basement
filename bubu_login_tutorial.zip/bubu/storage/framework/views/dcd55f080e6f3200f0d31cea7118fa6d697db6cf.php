<!DOCTYPE html>
<html lang="">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" 
              content="width=device-width, initial-scale=1">

        <title><?php echo $__env->yieldContent('title'); ?></title>


</head>
    <body>
        <h1>Wellcome to Laravel 6</h1>
        
        <p>With some additional text.</p>
    </body>
</html><?php /**PATH C:\xampp\bubu\resources\views/app.blade.php ENDPATH**/ ?>